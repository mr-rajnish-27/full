from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from accounts.models import User


def register(request):

    if request.method == 'POST':

        username = request.POST['username']
        password = request.POST['password']

        is_provider = request.POST.get('is_provider')

        user = User.objects.create_user(
            username=username,
            password=password
        )

        if is_provider:
            user.is_provider = True
            user.save()

        login(request, user)

        if user.is_provider:
            return redirect('/dashboard/')

        return redirect('/services/')

    return render(request, 'register.html')


def user_login(request):

    if request.method == 'POST':

        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user:

            login(request, user)

            if user.is_provider:
                return redirect('/dashboard/')

            return redirect('/services/')

        else:

            return render(
                request,
                'login.html',
                {'error': 'Invalid Username or Password'}
            )

    return render(request, 'login.html')


def user_logout(request):

    logout(request)

    return redirect('/')