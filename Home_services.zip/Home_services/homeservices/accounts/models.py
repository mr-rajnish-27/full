from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):

    is_provider = models.BooleanField(default=False)

    phone = models.CharField(
        max_length=15,
        blank=True
    )

    city = models.CharField(
        max_length=100,
        blank=True
    )

    address = models.TextField(
        blank=True
    )

    image = models.ImageField(
        upload_to='profile/',
        blank=True,
        null=True
    )