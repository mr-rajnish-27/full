from django.shortcuts import render, redirect
from .models import Booking
from services.models import Service
from django.contrib.auth.decorators import login_required
@login_required
def book_service(request,id):
    service=Service.objects.get(id=id)
    if request.method =='POST':
        Booking.objects.create(
            user=request.user,
            service=service,
            date=request.POST['date']
        )
        return redirect('/')
    return render(request, 'book.html',{'service':service})
# Create your views here.
